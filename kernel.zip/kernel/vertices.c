#include <stdio.h>
#include <stdlib.h>
#include "include/vertices.h"
#include "include/datastructure.h"
//static listnode *findlast(listnode *header);
static int vtkey=0,egkey=0,fck=0;
int GroupIndex=0,lastgroup[VOLUME_GROUP],lastface[VOLUME_GROUP];
vertice vt_i[VOLUME_VERTICE];
edge eg_i[VOLUME_EDGE];
crystaline *face_i[VOLUME_FACE],*group[VOLUME_GROUP];
VCollection groupVC[VOLUME_GROUP];
static void disposelist(crystaline *L);
static void add(edge e,crystaline **L);
static void AddEdgeToVertice(edge e,int key);

static int collected(int v,VCollection L);
//VCollection ExtractVertices(crystaline *L);
int scanface(FILE *input,int lg);
void RegisterFace(crystaline *L);
void ComboJoin(int v1,int v2,crystaline **L);
static void scanedge(FILE *input);
//------------------------
//void GenerateUnity(edge *e,crystaline *L);
//edge *KeyToEdge(int key);
//static void AddEdgeToVertice(edge e,int key);
//int inList(edge *e,crystaline *L);
//static void disposelist(crystaline *L);
//static void addtounity(edge *e,crystaline *L);
//------------------------
//void showvertice(vertice v);
//------------------------5.22
int scanface(FILE *input,int lastgroup){
//(done)all scanf should be replaced by fscanf,consider adding a FILE *
    int error,v0,v,vold;
    char c='f';
    crystaline *L=NULL;
    do{
        fscanf(input,"%d%d",&v0,&vold);
        ComboJoin(v0+lastgroup,vold+lastgroup,&L);
        while(fscanf(input,"%d",&v)==1){
            ComboJoin(vold+lastgroup,v+lastgroup,&L);
            vold=v;
        }
        ComboJoin(v+lastgroup,v0+lastgroup,&L);
        RegisterFace(L);
        L=NULL;
    }
    while(fscanf(input,"%c",&c)==1&&c=='f');
    if(feof(input))return 0;
    else return 1;
}
void RegisterFace(crystaline *L){
    face_i[fck++]=L;
}
void ComboJoin(int v1,int v2,crystaline **L){
    edge *ep;
    join(v1,v2);
    ep=calloc(1,sizeof(edge));
    ep->v1=v1;ep->v2=v2;
    add(*ep,L);
}
//------------------------
static int collected(int v,VCollection L){
    VCollection p;
    for(p=L;p;p=p->next)
        if(p->vp->key==v)return 1;
    return 0;
}
VCollection ExtractVertices(crystaline *L){
    crystaline *p;
    VCollection VC=NULL,nvc;
    for(p=L;p;p=p->next){
        if(!collected(p->e->v1,VC)){
            nvc=calloc(1,sizeof(struct vplist));
            nvc->vp=KeyToVertice(p->e->v1);
            nvc->next=VC;
            VC=nvc;
        }
        if(!collected(p->e->v2,VC)){
            nvc=calloc(1,sizeof(struct vplist));
            nvc->vp=KeyToVertice(p->e->v2);
            nvc->next=VC;
            VC=nvc;
        }
    }
    return VC;
}
//---------------------------
void FlushToDisk(void){
    int i,j,k;
    FILE *output;
    crystaline *p;
    output=fopen("data1.obj","w");
    for(j=0;j<GroupIndex;j++){
        fprintf(output,"g Object%03d\n",j+1);
        for(i=lastgroup[j]+1;i<lastgroup[j+1]+1;i++)
            fprintf(output,"v %8.6f %8.6f %8.6f\n",vt_i[i].x,vt_i[i].y,vt_i[i].z);
        if(j)k=lastface[j-1];else k=0;
        for(i=k;i<lastface[j];i++){
            fprintf(output,"f");
            for(p=face_i[i];p;p=p->next)
                fprintf(output," %d",p->e->v1-lastgroup[j]);
            fprintf(output,"\n");
        }
    }
        //-------------------
        //     for(i=0;i<egkey;i++)
        //        fprintf(output,"l %d %d\n",eg_i[i].v1,eg_i[i].v2);
        //-------------------
    fclose(output);
}
void LoadFromFile(void){
    char c,*s[31];
    double x,y,z;
    FILE *input;
    int v1,v2,e=0;
    input=fopen("data1.obj","r");
    vtkey=1;egkey=0;lastgroup[0]=0;
    do{
        fgets(s,30,input);
        do{
            c=fgetc(input);
            if(c=='v'||c=='V'){
                e=fscanf(input,"%lf%lf%lf\n",&x,&y,&z);
                if(e==EOF)return;
                RegisterVertice(*newvertice(x,y,z));
            }
        }
        while(c=='v'||c=='V');
        while(c=='\n')c=fgetc(input);
        if(c=='f'||c=='F')c='g'*scanface(input,lastgroup[GroupIndex]);
        // if(c=='l'||c=='L')scanedge(input);
    //     while((c=='l'||c=='L')&&e!=EOF){
    //         e=fscanf(input,"%d%d\n%c",&v1,&v2,&c);
    //         join(v1,v2);
    //     }
        GenerateUnity(eg_i+egkey-1,group+GroupIndex);
        groupVC[GroupIndex]=ExtractVertices(group[GroupIndex]);
        lastface[GroupIndex]=fck;
        GroupIndex++;
        lastgroup[GroupIndex]=vtkey-1;
    }
    while((c=='g'||c=='G')&&!(feof(input)));
    fclose(input);
}
static void scanedge(FILE *input){
    char c='l';
    int e=1,v1,v2;
    while(e!=EOF&&(c=='l'||c=='L')){
        fscanf(input,"%d%d\n",&v1,&v2);
        join(v1,v2);
        e=fscanf(input,"%c",&c);
    }
}
//--------------primitive version
vertice *KeyToVertice(int key){
    // if(vt_i[key].key!=0)
    return vt_i+key;
}
//--------------------------
void RegisterEdge(edge p){
    eg_i[p.key]=p;
}
void RegisterVertice(vertice v){
    vt_i[vtkey++]=v;
}
//-------------------
vertice* newvertice(double x,double y,double z){
    vertice *p;
    p=(vertice*)calloc(1,sizeof(vertice));
    p->x=x;
    p->y=y;
    p->z=z;
    p->header=NULL;
    return p;
}
//-----------------------
static void add(edge e,crystaline **L){
    crystaline *p;
    p=calloc(1,sizeof(crystaline));
    p->e=calloc(1,sizeof(edge));
    *(p->e)=e;
    p->next=*L;
    *L=p;
}
int inList(edge *e,crystaline *L){
    crystaline *p;
    p=L;
    while(p){
        if(p->e->key==e->key)return 1;
        p=p->next;
    }
    return 0;
}
static void disposelist(crystaline *L){
    if(L==NULL)return;
    if(L->next==NULL)free(L);
        else disposelist(L->next);
}
//---------------------------
// edge *KeyToEdge(int key){
//     return eg_i+key;
// }
//crystaline *newsolid(char *type);
//---------------------
//crystaline *newsolid(char *t){
//    crystaline *L;
//    L=malloc(sizeof(crystaline));
//
//}
//listnode *FindHeader(int verticekey){
//    vertice *v;
//    v=KeyToVertice(verticekey);
//    return v->header;
//}
static void AddEdgeToVertice(edge e,int vcode){
    vertice *v;
    v=KeyToVertice(vcode);
    add(e,&(v->header));
}
int join(int v1,int v2){
//cool
    edge e;
    crystaline *p1;
    int joined=0;
    if(KeyToVertice(v1)->header&&KeyToVertice(v2)->header){
        for(p1=KeyToVertice(v1)->header;p1->next;p1=p1->next)
            if(p1->e->v2==v2||p1->e->v1==v2)break;
        if(p1->e->v2==v2||p1->e->v1==v2) joined=1;
    }
    if(joined)return -1;
    e.key=egkey++;
    e.v1=v1;e.v2=v2;
    RegisterEdge(e);
    AddEdgeToVertice(e,v1);
    AddEdgeToVertice(e,v2);
    return 0;
}
void GenerateUnity(edge *e,crystaline **L){
//----O(E^2)algorithm
    crystaline *p;
    disposelist(*L);
    pushin(e);
    do{
        do e=popout();
        while(e&&inList(e,*L));
//        if(e)showedge(*e);
        if(e==NULL)break;
        add(*e,L);
        for(p=KeyToVertice(e->v1)->header;p;p=p->next) if(!inList(p->e,*L)) pushin(p->e);
        for(p=KeyToVertice(e->v2)->header;p;p=p->next) if(!inList(p->e,*L)) pushin(p->e);
    }
    while(1);
}
//--------------------
// int main(void){
//     int i,j,k;
//     for(i=-1;i<2;i+=2)
//         for(j=-1;j<2;j+=2)
//             for(k=-1;k<2;k+=2){
//                 RegisterVertice(*newvertice(i,j,k));
//                 // if(vtkey)connect(vtkey-1,vtkey);
//             }
//    for(i=0;i<8;i++)showvertice(vt_i[i]);
//    for(i=0;i<4;i++){
//        join(i,i+4);
//        join(2*i,2*i+1);
//    }
//    join(0,2);join(1,3);
//    join(4,6);join(5,7);
//    for(i=0;i<12;i++)showedge(eg_i[i]);
//    return 0;
// }
// void showvertice(vertice v){
//    printf("%f %f %f\n",v.x,v.y,v.z);
// }
// void showedge(edge e){
//    printf("//");
//    showvertice(*KeyToVertice(e.v1));
//    showvertice(*KeyToVertice(e.v2));
//    printf("//");
// }
