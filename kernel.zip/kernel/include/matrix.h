typedef double element;
typedef struct mat{
    int row;
    int column;
    element **a;
} *matrix;
matrix cross(matrix A,matrix B);
matrix newmatrix(int r,int c);
double measure(matrix A);
//----value is 0 if A is not a vector
void normalize(matrix A);
matrix transverse(matrix A);
//------------------------
// int rank(matrix A);
// matrix solve(matrix A,matrix A_bar);
// element det(matrix A);
// matrix reverse(matrix A);
// matrix newcopy(matrix A);
//-------------------------
void duplicate(element k,matrix A);
void printmatrix(matrix A);
void definematrix(matrix A);
void dispose(matrix A);
//-------------------------
