#define VERTICES_INCLUDED 0xAAAA
#define VOLUME_VERTICE 10000
#define VOLUME_FACE 10000
#define VOLUME_EDGE 20000
#define VOLUME_GROUP 100
//typedef struct ListNode{
//    int generalkey;
//    struct ListNode *next;
//} listnode;
typedef struct{
    int v1;
    int v2;
    int key;
} edge;
typedef struct Crystal{
    edge* e;
    struct Crystal *next;
} crystaline;
typedef struct{
    double x;
    double y;
    double z;
    int key;
    crystaline *header;
} vertice;
typedef struct{
    double x;
    double y;
} R_2;
typedef struct vplist{
    vertice *vp;
    struct vplist *next;
} *VCollection;
vertice* newvertice(double x,double y,double z);
vertice* KeyToVertice(int key);
int join(int v1,int v2);
void RegisterEdge(edge p);
void RegisterVertice(vertice p);
void GenerateUnity(edge *e,crystaline **L);
int inList(edge *e,crystaline *L);
void FlushToDisk(void);
void LoadFromFile(void);
VCollection ExtractVertices(crystaline *L);
