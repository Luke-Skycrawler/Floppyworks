#ifndef volume
#define volume 100
#endif // volume
int pushin(edge *x);
edge* popout(void);
