#include <stdio.h>
#include "include/vertices.h"
typedef struct{
    edge* e;
    crystaline *next;
} crystaline;
//listnode *FindHeader(int verticekey);
static listnode *findlast(listnode *header);
static void AddEdgeToVertice(edge e,int key);
//crystaline *newsolid(char *type);
//---------------------
//crystaline *newsolid(char *t){
//    crystaline *L;
//    L=malloc(sizeof(crystaline));
//
//}
//listnode *FindHeader(int verticekey){
//    vertice *v;
//    v=KeyToVertice(verticekey);
//    return v->header;
//}
static void AddEdgeToVertice(edge e,int vkey){
    vertice *v;
    listnode *p;
    v=KeyToVertice(vkey);
    p=calloc(sizeof(listnode));p->generalkey=e.key;
    if(v->header){
        p->next=v->header->next;
        v->header=p;
    }
    else v->header=p;
}
void join(int v1,int v2){
    edge e;
    listnode *p1,*p2;
    int joined=0;
    if(KeyToVertice(v1)->header*KeyToVertice(v2))
        for(p1=KeyToVertice(v1)->header;p1->next;p1=p1->next)
            if(KeyToEdge(p1->generalkey)->v2==v2||KeyToEdge(p1->generalkey)->v1)break;
    if(KeyToEdge(p1->generalkey)->v2==v2||KeyToEdge(p1->generalkey)->v1) joined=1;
    if(joined)return;
//-------------------code above is new
    e.key=egkey++;
    e.v1=v1;e.v2=v2;
    RegisterEdge(e);
//-------------------code below is untestified
    AddEdgeToVertice(e,v1);
    AddEdgeToVertice(e,v2);
//-------------------
//    p1=FindHeader(v1);
//    p2=FindHeader(v2);
//    if(p1||p2)
//        if(p1==NULL){
//            p1=malloc(sizeof(listnode));p1->generalkey=v1;
//            p1->next=p2->next;
//            p2->next=p1;
//            KeyToVertice(v1)->header=p2;
//        }
//        else if(p2==NULL){
//            p2=malloc(sizeof(listnode));p2->generalkey=v2;
//            p2->next=p1->next;
//            p1->next=p2;
//            KeyToVertice(v2)->header=p1;
//        }
//        else {
//            findlast(p2)->next=p1->next;
//            findlast(p1)->next=p2->next;
//            KeyToVertice(v2)->header=p1;
//        }
//    else {
//        p1=malloc(sizeof(listnode));p1->generalkey=v1;
//        p2=malloc(sizeof(listnode));p2->generalkey=v2;
//        KeyToVertice(v1)->header=KeyToVertice(v2)->header=p1;
//        p1->next=p2;
//        p2->next=p1;
//    }
}
static listnode *findlast(listnode *header){
    listnode *p;
    p=header->next;
    for(p=header->next;p->next!=header;p=p->next);
    return p;
}
//----------------------
int main(void){

}
