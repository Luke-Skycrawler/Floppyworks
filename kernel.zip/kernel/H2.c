#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include "include\graphics.h"
#include "include\genlib.h"
#include "conio.h"
#include <math.h>
#include <windows.h>
#include <olectl.h>
#include <stdio.h>
#include <mmsystem.h>
#include <wingdi.h>
#include <ole2.h>
#include <ocidl.h>
#include <winuser.h>
//-------------------------
#include "include/vertices.h"
#include "include/matrix.h"
#define PENBOLDFACE 8
#define PENLIGHT 1

#define DELTATHETA (M_PI/24)
#define DELTAL 0.1
//-------------------------
static double cx,cy,proportion=1;
static matrix RotationVector,CameraPosition;

static matrix xaxis,yaxis,zaxis;
//-------------------------
extern int GroupIndex;
extern vertice vt_i[VOLUME_VERTICE];
extern edge eg_i[VOLUME_EDGE];
extern crystaline *face_i[VOLUME_FACE],*group[VOLUME_GROUP];
extern VCollection groupVC[VOLUME_GROUP];
//-------------------------
//void display(double n);
static R_2 projection(vertice v);
matrix vector(vertice v);
matrix spin(matrix axis,double theta);
//-------------------------display interfaces
static void drawvertice(R_2 c);
static void drawedge(edge *e);
void DisplayCrystal(crystaline *L,VCollection VC);
void display_all(void);
//-------------------------
// static crystaline *listcry;
// static VCollection listvertice;
//-------------------------
void display_all(void){
//very primitive
    int i;
//    for(i=0;i<8;i++)showvertice(vt_i[i]);
    for(i=0;i<GroupIndex;i++)DisplayCrystal(group[i],groupVC[i]);
    // DisplayCrystal(listcry,listvertice);
}
void DisplayCrystal(crystaline *L,VCollection VC){
    crystaline *p;
    VCollection v;
    for(p=L;p;p=p->next)drawedge(p->e);
    for(v=VC;v;v=v->next)drawvertice(projection(*v->vp));
}
void RotControl(int key,int event);
void MovControl(int key);
//-------------------------
static void drawvertice(R_2 c){
    SetPenSize(PENBOLDFACE);
    //-------could use some optimization, such as prepare the color and size just once
    SetPenColor("Red");
    MovePen(cx+c.x,cy+c.y);
    DrawLine(0,0);
}
static void drawedge(edge *e){
    R_2 aftermath1,aftermath2;
    SetPenSize(PENLIGHT);
    SetPenColor("Black");
    aftermath1=projection(*(KeyToVertice(e->v1)));
    aftermath2=projection(*KeyToVertice(e->v2));
    MovePen(aftermath2.x+cx,aftermath2.y+cy);
    DrawLine(aftermath1.x-aftermath2.x,aftermath1.y-aftermath2.y);
}
static R_2 projection(vertice v){
//---------primitive version, equavilient to the map along y axis
    R_2* f;
    matrix r;
    f=malloc(sizeof(R_2));
//    f->x=v.x;
//    f->y=v.z;
//---------------------
    r=vector(v);
    *r=*cross(transverse(RotationVector),r);
    r->a[0][0]+=CameraPosition->a[0][0];
    r->a[1][0]+=CameraPosition->a[1][0];
    r->a[2][0]+=CameraPosition->a[2][0];
    f->x=r->a[0][0]*proportion;
    f->y=r->a[2][0]*proportion;
//---------------------
    return *f;
}
matrix vector(vertice v){
    matrix r;
    r=newmatrix(3,1);
    r->a[0][0]=v.x;
    r->a[1][0]=v.y;
    r->a[2][0]=v.z;
    return r;
}
matrix spin(matrix axis,double theta){
    matrix M;
    int i;
    double alpha,beta,c,b,a;
    normalize(axis);
    c=axis->a[2][0];b=axis->a[1][0];a=axis->a[0][0];
    alpha=sin(theta);
    beta=cos(theta);
    M=cross(axis,transverse(axis));
    duplicate(1-beta,M);
    for(i=0;i<3;i++)M->a[i][i]+=beta;
    M->a[0][1]+=c*alpha;M->a[1][0]-=c*alpha;
    M->a[0][2]-=b*alpha;M->a[2][0]+=b*alpha;
    M->a[1][2]+=a*alpha;M->a[2][1]-=a*alpha;
//    p=cross(M,r);
//    return p;
    return M;
}
//------------------------
void RotControl(int key,int event){
//    matrix xaxis,zaxis,yaxis;
    if(event!=KEY_DOWN)return;
    switch(key){
    case VK_LEFT:
        RotationVector=cross(RotationVector,spin(zaxis,-DELTATHETA));
        DisplayClear();
        display_all();
        break;
    case VK_RIGHT:
        RotationVector=cross(RotationVector,spin(zaxis,DELTATHETA));
        DisplayClear();
        display_all();
        break;
    case VK_DOWN:
        RotationVector=cross(RotationVector,spin(xaxis,DELTATHETA));
        DisplayClear();
        display_all();
        break;
    case VK_UP:
        RotationVector=cross(RotationVector,spin(xaxis,-DELTATHETA));
        DisplayClear();
        display_all();
        break;
    case VK_ESCAPE:
        FlushToDisk();
        ExitGraphics();
        break;
    case 187:
        proportion+=0.1;
        DisplayClear();
        display_all();
        break;
    case 189:
        proportion-=0.1;
        DisplayClear();
        display_all();
        break;
//    case VK_SPACE:
//        RotationVector=cross(RotationVector,spin(yaxis,-DELTATHETA));
//        DisplayClear();
//        display_all();
//        break;
//    case VK_BACK:
//        RotationVector=cross(RotationVector,spin(yaxis,DELTATHETA));
//        DisplayClear();
//        display_all();
//        break;
    }
}
void MovControl(int key){
    switch(key){
    case 'q':case 'Q':
        RotationVector=cross(RotationVector,spin(yaxis,-DELTATHETA));
        DisplayClear();
        display_all();
        break;
    case 'e':case 'E':
        RotationVector=cross(RotationVector,spin(yaxis,DELTATHETA));
        DisplayClear();
        display_all();
        break;
    case 'w':case 'W':
        CameraPosition->a[2][0]-=DELTAL;DisplayClear();display_all();break;
    case 's':case 'S':
        CameraPosition->a[2][0]+=DELTAL;DisplayClear();display_all();break;
    case 'a':case 'A':
        CameraPosition->a[0][0]+=DELTAL;DisplayClear();display_all();break;
    case 'd':case 'D':
        CameraPosition->a[0][0]-=DELTAL;DisplayClear();display_all();break;
//    case 'x':case 'X':
//        proportion+=0.1;
//        DisplayClear();
//        display_all();
//        break;
//    case 'c':case 'C':
//        proportion-=0.1;
//        DisplayClear();
//        display_all();
//        break;
    }
}
//------------------------
void Main(void)
{
    int i,j,k;
    CameraPosition=newmatrix(3,1);
    RotationVector=newmatrix(3,3);
    for(i=0;i<3;i++)
        RotationVector->a[i][i]=1;
    xaxis=newmatrix(3,1);xaxis->a[0][0]=1;
    zaxis=newmatrix(3,1);zaxis->a[2][0]=1;
    yaxis=newmatrix(3,1);yaxis->a[1][0]=1;
    InitGraphics();
    cx = GetWindowWidth()/2;
    cy = GetWindowHeight()/2;
    MovePen(cx,cy);
//    drawvertice(cx,cy);
//------------------------------
//     for(i=-1;i<2;i+=2)
//         for(j=-1;j<2;j+=2)
//             for(k=-1;k<2;k+=2){
//                 RegisterVertice(*newvertice(i,j,k));
//                 // if(vtkey)connect(vtkey-1,vtkey);
//             }
//    for(i=0;i<4;i++){
//        join(i,i+4);
//        join(2*i,2*i+1);
//    }
//    join(0,2);join(1,3);
//    join(4,6);join(5,7);
//------------------------------
//    for(i=1;i<5;i++)
//        for(j=1;j<5;j++)
//            if(j!=i)join(i,j);
    LoadFromFile();
    // GenerateUnity(eg_i,&listcry);
    // listvertice=ExtractVertices(listcry);
//    DisplayCrystal(L);
    display_all();
    registerKeyboardEvent(RotControl);
    registerCharEvent(MovControl);
//-------------------------------
    return 0;
}
void display(double n){
    char c[6];
    sprintf(c,"%.2f  ",n);
    DrawTextString(c);
}
void showvertice(vertice v){
    drawvertice(projection(v));
}
